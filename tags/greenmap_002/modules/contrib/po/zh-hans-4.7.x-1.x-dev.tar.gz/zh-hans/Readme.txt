﻿本次翻译在Drupal的中文官方社区 http://www.drupalchina.org 完成。

参与翻译翻译的贡献者包括：大米，hexic,holz,kzeng,fermi,linfengqi,niveko，在此特别鸣谢。关于汉化的讨论的可以参看：http://www.drupalchina.org/forum/8 ，欢迎您的积极参与！
