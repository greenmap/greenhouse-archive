Textimage
-------------

This module performs two functions:
1. Provides an image challenge captcha. You will need to install captcha.module first.
2. Provides all text->image functionalities, for things like automated custom headers, etc. (not implemented yet)



INSTALLING
-------------
1. Copy all the files to your modules folder.
2. Enable textimage in Admin->Modules
3. Give the right permissions in Admin->Acess Control

